import numpy as np
import os
import subprocess as su
import pickle as pc
import sys
import json
from driver_manager import main as dmain
import scipy.ndimage as ndimage
zoom = ndimage.interpolation.zoom
from datetime import datetime
import argparse
from glob import glob
       
def parse(inps):
    parser = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('-b', '--batch_size', type = str, default = '256', help = 'batch_size')
    parser.add_argument('-d', '--ddir', type = str, required = True, help = 'Data directory')
    parser.add_argument('-g', '--gpu_frac', type = str, default = '1', help = 'gpu fraction')
    parser.add_argument('-i', '--input_file', type = str, required = True, help = 'json input file name for the model')
    parser.add_argument('-m', '--model', type = str, required = True, help = 'Model name')
    parser.add_argument('-p', '--pdir', type = str, required = True, help = 'Output directory for predictions')
    parser.add_argument('-r', '--mdir', type = str, required = True, help = 'model directory')
    parser.add_argument('-s', '--suffix', type = str, default = 'dbf.pck', help = 'File suffix of the input data to do regex')
    parser.add_argument('-v', '--visible_gpu', type = str, default = '4', help = 'the gpu to be used')

    return parser.parse_args(inps)

def main(args):
    inps = parse(args)
    lsdir = inps.ddir
    infile = inps.input_file
    pred_dir = inps.pdir
    model = inps.model
    suffix = inps.suffix
    gpu_frac = inps.gpu_frac
    vgpu = inps.visible_gpu
    batch_size = inps.batch_size
    mdir = inps.mdir
    if not os.path.exists(pred_dir):
        os.mkdir(pred_dir)
    ls = glob(os.path.join(lsdir,'*' + suffix))
    inps = json.load(open(infile))
    for l in ls:
        inps['data_file'][2] = os.path.join(lsdir,l)
        jsonfname = 'input_file_ps.json'
        json.dump(inps,open(jsonfname,'w'))          
        cmd =  '-a tf -f ' + jsonfname + ' -d ' + lsdir + ' -m  ' + model +  ' -b ' + batch_size + ' -i 2 -x ps -v ' + vgpu + ' -g ' + gpu_frac + ' --pred_dir ' + pred_dir + ' -q ' + mdir 
        dmain(cmd.split())
        pass
    
if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))