import tensorflow as tf
import argparse
import json
import sys
import os
from TFManager import TFManager
from QTFManager import QTFManager
TMP_DIR = os.path.join(os.environ['HOME'],'Workspace/Data/ml_log') 
def parse(inps):
        parser = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter)
        parser.add_argument('-a', '--ma_type', type = str, default = 'qtf', dest = 'ma_type', help = 'manager type')
        parser.add_argument('-b', '--batch_size', type = int, default = 32, dest = 'batch_size', help = 'batch_size')
        parser.add_argument('-c', '--use_all', action='store_true', dest = 'use_all', help = 'use all data in batch when testing')
        parser.add_argument('-d', '--ddir', type = str, default = './', dest = 'ddir', help = 'data directory')
        parser.add_argument('-e', '--reload', action='store_true', dest = 'reload', help = 'if log dir exists reload from checkpoint')
        parser.add_argument('-f', '--file', type = str, default = '', dest = 'file', help = 'input file')
        parser.add_argument('-g', '--gpu_frac', type = float, default = 1, dest = 'gpu_frac', help = 'gpu fraction')
        parser.add_argument('-i', '--is_train', type = int, default = 1, dest = 'is_train', help = '0 if test 1 if train 2 if predict')
        parser.add_argument('-j', '--save_best', type = int, default = 0, dest = 'save_best', help = '0: do nothing, 1: during testing save best model score, 2: during test load best model')
        parser.add_argument('-k', '--class_thr', type = float, default = -1, dest = 'class_thr', help = 'if set to a value in (0,1) the true class is selected if prob(1) > class_thr, otherwiwe argmax is sed')
        parser.add_argument('-l', '--learning_rate', type = float, default = -1, dest = 'learning_rate', help = 'learning rate')
        parser.add_argument('-m', '--model_id', type = str, default = '0', dest = 'model_id', help = 'model id')
        parser.add_argument('-n', '--nema', type = int, default = 50, dest = 'nema', help = 'number of point for ema of loss')
        parser.add_argument('-o', '--eager', action='store_true', dest = 'eager', help = 'run eagerly')
        parser.add_argument('-p', '--sleep', type = int, default = 20, dest = 'sleep', help = 'sleep during testing')
        parser.add_argument('-q', '--log_dir', type = str, default = TMP_DIR, dest = 'log_dir', help = 'log directory')
        parser.add_argument('-r', '--rm_log_dir', action='store_true', dest = 'rm_log_dir', help = 'remove log dir for current model_id')
        parser.add_argument('-s', '--std_to_file', action='store_true', dest = 'std_to_file', help = 'flag to write sdtout to file')
        parser.add_argument('-t', '--std_file', type = str, default = 'run.log', dest = 'std_file', help = 'file name to redirect stdout')
        parser.add_argument('-u', '--debug', action='store_true', dest = 'debug', help = 'run session if debugger')
        parser.add_argument('-v', '--visible_gpu', type = str, default = '0', dest = 'visible_gpu', help = 'the gpu to be used')
        parser.add_argument('-x', '--log_suffix', type = str, required=True, dest = 'log_suffix', help = 'suffix to log dir')
        parser.add_argument('-y', '--summary', action='store_true', dest = 'summary', help = 'print accuracy summary')
        parser.add_argument('-w', '--summary_test', action='store_true', dest = 'summary_test', help = 'print accuracy summary for test during training')
        parser.add_argument('-z', '--validation_batch_size', type = int, default = -1, dest = 'validation_batch_size', help = 'validation batch_size. -1 is all')
        parser.add_argument('--save_metric', type = str, default = 'f1', dest = 'save_metric', help = 'which metric to use to save best model. Values accuracy, precision, recall or f1. Default f1. If more than 2 classes only accuracy.')
        parser.add_argument('--pred_dir', type = str, default = '', dest = 'pred_dir', help = 'Directory where to save the predictions.')

        return parser.parse_args(inps)
        
def main(cmd_line):
    inps = parse(cmd_line)
    args = json.load(open(inps.file))
    #some of the parameters is better to change them from command line, especailly
    #if running multiple experiments
    for k in inps.__dict__.keys():
        args[k] = inps.__dict__[k]
    args['log_dir'] = os.path.join(args['log_dir'],args['log_suffix']) 
    #args['is_train'] = True if args['is_train'] == 1 else False
    if inps.learning_rate > 0:
        args["optimizer_args"][0] = inps.learning_rate
    if inps.ma_type == 'tf':
        tfm = TFManager()
    elif inps.ma_type == 'qtf':
        tfm = QTFManager()
    else:
        print('Unrecognized manager type',inps.ma_type)
        raise ValueError
    if args['is_train'] <  2:
        tfm.run(args)
    elif args['is_train'] == 2:
        if len(args['pred_dir']) == 0:
            args['pred_dir'] = args['ddir']
        tfm.predict(args)
    else:
        print('Unrecognized value is_train',args['is_train'])
        raise ValueError
if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))