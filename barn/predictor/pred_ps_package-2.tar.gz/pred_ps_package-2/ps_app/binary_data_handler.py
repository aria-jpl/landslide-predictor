from data_handler import DataHandler
import sys
import numpy as np
import os
import pickle as cp
class BinaryDataHandler(DataHandler):
    def __init__(self,bsize,shuffle=True,init_file=''):
        self._white = True
        super().__init__(bsize,shuffle=True,init_file=init_file)
                
    def split_data(self,validation,split,shuffle=True):
        """
        Split the data and labels in a train,validation and test sets based on 
        the fractions devined in split
        inputs:
            validation: instance for validation
            split: split for train
            shuffle: bool, if true train and validation are shuffle (test needs to stay the same)
        outputs: 
            sets the _data and _labels fro train and validation 
        """
            
        _train_num = int(self._data.shape[0]*split)
        _valid_num = self._data.shape[0]  - _train_num
        
        #possible shuffle train and valid
        if shuffle:
            indx = np.arange(_train_num + _valid_num)
            np.random.shuffle(indx)
            self._data = self._data[indx]
            self._labels = self._labels[indx]
            if self._weights is not None:
                self._weights = self._weights[indx]

        _train_x = self._data[0:_train_num,:]
        _train_y = self._labels[0:_train_num] 
        _valid_x = self._data[_train_num:,:]
        _valid_y = self._labels[_train_num:] 
       
        if self._weights is not None:
            _train_w = self._weights[0:_train_num] 
            _valid_w = self._weights[_train_num:]
        else:
            _train_w = None 
            _valid_w = None
        self._data = _train_x
        self._labels = _train_y
        self._weights = _train_w
        validation._data = _valid_x
        validation._labels = _valid_y
        validation._weights = _valid_w
        
        return
    
    def whiten(self,data):
        if len(data.shape) == 2:
            #1d data type [num_samples,dim]
            meanx = np.mean(data,1,keepdims=True)
            stdx =  np.std(data,1,keepdims=True)
        elif len(data.shape) == 3:
            #1d data type [num_samples,dim1,channels]
            meanx = np.mean(data,1,keepdims=True)
            stdx =  np.std(data,1,keepdims=True)
        elif len(data.shape) == 4:
            #2d data type [num_samples,dim1,dim2,channels]
            meanx = np.mean(data,(1,2),keepdims=True)
            stdx = np.std(data,(1,2),keepdims=True)
        else:
            print("Data must be 2, 3 or 4 dimensional")
            raise Exception
        return (data - meanx)/stdx
    
    def load_data(self,fname,ddir='./'):
        '''
        Load data from a pickle file. The assumption is that it contains a dictionary
        with the keys "data" and "labels". Override method if necessary
        inputs:
            fname: name of the pickle file.
            ddir: data directory
        outputs:
            data,labels: data is type np.float32, labels is np.int32 if is_int is True (default)
            or np.float32 otherwise, depending if doing classificaton or regression 
        '''
        ldata = cp.load(open(os.path.join(ddir,fname),'rb'))
        #to reshape ans recast the data make sure to set self._new_shape* and
        #self._data_type (or labels) 
        if 'labels' in ldata:
            if 'weights' in ldata:
                if self._white:
                    self._data, self._labels, self._weights  =  self.whiten(ldata['data']), ldata['labels'], self.whiten(ldata['weights'])
                else:
                    self._data, self._labels, self._weights  =  ldata['data'], ldata['labels'], ldata['weights']
                if self._new_shape_data:
                        self._data = np.reshape(self._data,self._new_shape_data) 
                if self._new_shape_labels:
                    self._labels = np.reshape(self._labels,self._new_shape_labels) 
                    self._weights = np.reshape(self._weights,self._new_shape_labels) 
                if self._data_type:
                    self._data = self._data.astype(getattr(np,self._data_type))
                if self._labels_type:
                    self._labels = self._labels.astype(getattr(np,self._labels_type))
                    self._weights = self._weights.astype(getattr(np,self._labels_type))
                
            else:
                if self._white:
                    self._data, self._labels, self._weights  =  self.whiten(ldata['data']), ldata['labels'], None
                else:
                    self._data, self._labels, self._weights  =  ldata['data'], ldata['labels'], None
                if self._new_shape_data:
                    self._data = np.reshape(self._data,self._new_shape_data) 
                if self._new_shape_labels:
                    self._labels = np.reshape(self._labels,self._new_shape_labels) 
                if self._data_type:
                    self._data = self._data.astype(getattr(np,self._data_type))
                if self._labels_type:
                    self._labels = self._labels.astype(getattr(np,self._labels_type))
        else:#inference no labels provided
            if self._white:
                    self._data, self._labels, self._weights =  self.whiten(ldata['data']), None, None
            else:
                self._data, self._labels, self._weights  =  ldata['data'], None, None
            if self._new_shape_data:
                self._data = np.reshape(self._data,self._new_shape_data) 
            if self._data_type:
                self._data = self._data.astype(getattr(np,self._data_type))
            self._data_size = self._data.shape[0]
        return
            
    def next_batch(self):
        if self._labels is not None:
            "Returns the next batch of data and labels"
            if self._batch_size < 0:
                start = 0
                end = self._data.shape[0]
            else:
                start = self._indx_now
                if(start + self._batch_size > self._data.shape[0]):
                    self._epochs += 1
                    start = 0
                    if self._shuffle:
                        x = np.arange(self._data.shape[0])
                        np.random.shuffle(x)
                        self._data = self._data[x]
                        self._labels = self._labels[x]
                end = start + self._batch_size
                self._indx_now = end
            if self._weights is None:
                return self._data[start:end],self._labels[start:end],None
            else:
                return self._data[start:end],self._labels[start:end],self._weights[start:end]
        else:#inference
            start = self._indx_now            
            end = start + self._batch_size
            if end > self._data.shape[0]:
                return np.concatenate([self._data[start:],self._data[0:end - self._data.shape[0]]]), None,None
            else:
                self._indx_now = end
                return self._data[start:end],None,None
        