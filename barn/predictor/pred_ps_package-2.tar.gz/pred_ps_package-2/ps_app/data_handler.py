import numpy as np
import pickle as cp
import os    
import abc
import json
class DataHandler(metaclass=abc.ABCMeta):
    """
    Provide interface for batched data
    """
    @abc.abstractmethod
    def load_data(self,fname,ddir='./'):
        return
    
    
    def __init__(self,bsize,shuffle=True,init_file=''):
        """
        data: array with data
        labels: array with labels
        weights: array with weights for labels. Only for regression
        bsize: batch size
        shuffle: bool, if true shuffle after each epoch
        dataset_type: 0 = train, 1 = validation, 2 = test
        """
        
        self._batch_size = bsize
        self._indx_now = 0 # current start index in dataset
        self._data = None
        self._labels = None
        self._weights = None
        #casting to int should work even if data is a tf Tensor
        self._data_size = None
        self._epochs = 0 #number of epochs
        self._shuffle = shuffle #shuffle at end of each epoch
        self._new_shape_data = None
        self._new_shape_labels = None
        self._data_type = None
        self._labels_type = None
        self._is_train = True
        self._use_all = False
        #this allows to init any attribute by putting the key value
        #into a json file
        self._init(init_file)
        self._config()

    #allow for customization at init 
    def _config(self):
        return   
    def _init(self,init_file):
        """
        Set attributes in the derived class using a json file with the name of the class and json
        extension in the cwd.
        If the class does not have the attribute it raises a ValueError exception.
        Used to initialize params that are not in the base class and not part of the main workflow
        initialization process.
        """
        if init_file and os.path.exists(init_file):
            vals = json.load(open(init_file))
            for k,v in vals.items():
                if k == 'comment':
                    continue
                if hasattr(self, k):
                    setattr(self,k,v)
                else:
                    print('attribute',k,'not present')
                    raise ValueError
        elif init_file:
            print('Cannot open file',init_file)
            raise ValueError
    
    @abc.abstractmethod                      
    def next_batch(self):
        return